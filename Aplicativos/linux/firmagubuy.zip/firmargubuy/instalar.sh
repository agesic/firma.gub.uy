#!/bin/bash

## Registar un tipo MIME para FirmaGubUY

#Instalar el archivo xml para el usuario
mkdir -p $HOME/.local/share/mime/packages
cp firmagubuy.xml $HOME/.local/share/mime/packages

#Actualizar la base de datos de tipos mime
update-mime-database $HOME/.local/share/mime

## Registrar una aplicación para el tipo MIME

#Actualizar la ruta al aplicativo dentro del archivo .desktop
cp firmagubuy.template firmagubuy.desktop
sed -i "s:InstallDir:$(pwd):g" firmagubuy.desktop

#Instalar el archivo .desktop para el usuario
desktop-file-install --dir=$HOME/.local/share/applications firmagubuy.desktop

#Actualizar la base de datos de aplicaciones
update-desktop-database $HOME/.local/share/applications

#Eliminar el archivo temporal
#rm firmagubuy.desktop
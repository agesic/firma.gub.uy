#!/bin/bash

## Quitar el tipo MIME

#Eliminar el archivo xml para el usuario
rm $HOME/.local/share/mime/packages/firmagubuy.xml

#Actualizar la base de datos de tipos mime
update-mime-database $HOME/.local/share/mime

## Quitar la aplicación

#Eliminar el archivo .desktop para el usuario
rm $HOME/.local/share/applications/firmagubuy.desktop

#Actualizar la base de datos de aplicaciones
update-desktop-database $HOME/.local/share/applications

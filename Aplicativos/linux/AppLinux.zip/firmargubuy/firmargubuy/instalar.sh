#!/bin/bash

#Utils
FIRMAGUBUY="firmagubuy"
FIRMAGUBUY_DESKTOP="firmagubuy.desktop"
FIRMAGUBUY_XML="firmagubuy.xml"
FIRMAGUBUY_TEMPLATE="firmagubuy.template"
PATH_MIME="/usr/share/mime"
PATH_MIME_PACKAGE="$PATH_MIME/packages"
PATH_FIRMAGUBUY="/opt/$FIRMAGUBUY"
PATH_FIRMAGUBUY_DESKTOP="/usr/share/applications"
PATH_FIRMAGUBUY_DESKTOP_FILE="$PATH_FIRMAGUBUY_DESKTOP/$FIRMAGUBUY_DESKTOP"

#Instalar el archivo xml para el usuario
mkdir -p "$PATH_MIME_PACKAGE"
cp $FIRMAGUBUY_XML $PATH_MIME_PACKAGE/
#Actualizar la base de datos de tipos mime
update-mime-database $PATH_MIME

## Crear directorio "$PATH_FIRMAGUBUY"
mkdir -p "$PATH_FIRMAGUBUY"

#Copiar la aplicación a opt
cp -r jre $PATH_FIRMAGUBUY
cp -r libs $PATH_FIRMAGUBUY
cp  logo.png $PATH_FIRMAGUBUY 
cp  *.jar $PATH_FIRMAGUBUY/$FIRMAGUBUY.jar

#Crear el file .desktop
cp $FIRMAGUBUY_TEMPLATE $PATH_FIRMAGUBUY_DESKTOP_FILE

update-desktop-database
echo "Success"

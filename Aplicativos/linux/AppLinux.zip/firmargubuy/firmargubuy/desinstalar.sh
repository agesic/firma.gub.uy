#!/bin/bash

#Utils
FIRMAGUBUY="firmagubuy"
FIRMAGUBUY_DESKTOP="firmagubuy.desktop"
FIRMAGUBUY_XML="firmagubuy.xml"
FIRMAGUBUY_TEMPLATE="firmagubuy.template"
PATH_MIME="/usr/share/mime"
PATH_MIME_PACKAGE="$PATH_MIME/packages"
PATH_FIRMAGUBUY="/opt/$FIRMAGUBUY"
PATH_FIRMAGUBUY_DESKTOP="/usr/share/applications"
PATH_FIRMAGUBUY_DESKTOP_FILE="$PATH_FIRMAGUBUY_DESKTOP/$FIRMAGUBUY_DESKTOP"
PATH_FIRMAGUBUY_XML_FILE="$PATH_MIME_PACKAGE/$FIRMAGUBUY_XML"

#Eliminar el archivo xml para el usuario
if [ -f "$PATH_FIRMAGUBUY_XML_FILE" ]; then
    rm "$PATH_FIRMAGUBUY_XML_FILE"
fi

#Actualizar la base de datos de tipos mime
update-mime-database "$PATH_MIME"

## Quitar la aplicación
#Eliminar el archivo .desktop para el usuario
if [ -f "$PATH_FIRMAGUBUY_DESKTOP_FILE" ]; then
    rm "$PATH_FIRMAGUBUY_DESKTOP_FILE"
fi

#Eliminar directorio de instalación
if [ -d $PATH_FIRMAGUBUY ]; then
    rm -rf  $PATH_FIRMAGUBUY
fi

#Actualizar la base de datos de aplicaciones
update-desktop-database
echo "Success"
